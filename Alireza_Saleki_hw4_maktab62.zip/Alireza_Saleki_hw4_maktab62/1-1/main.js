let suffix = ['rd', 'th', 'nd', 'st'];
let color = ['Blue', 'Green', 'Red', 'Black', 'Yellow', 'Orange', 'White', 'Purple',
    'Violet', 'Indigo', 'Gray', 'Pink'];


function printColor(suffix, color) {
    let result = "Result =>\n"
    for (let i = 0; i < color.length; i++) {
        if (i === 0) {
            result += (`${i + 1}${suffix[3]} choice is ${color[i]} \n`);
        } else if (i === 1) {
            result += (`${i + 1}${suffix[2]} choice is ${color[i]} \n`);
        } else if (i === 2) {
            result += (`${i + 1}${suffix[0]} choice is ${color[i]} \n`);
        } else {
            result += (`${i + 1}${suffix[1]} choice is ${color[i]} \n`);
        }
    }
    return result;
}
console.log(printColor(suffix, color));