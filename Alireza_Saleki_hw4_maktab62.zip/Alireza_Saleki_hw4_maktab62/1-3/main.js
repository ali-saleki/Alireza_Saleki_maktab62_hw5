let depth = 0;
let arr = [10, [25, 13], [14, [55], 2]];

function getArrayDepth(array) {

    for (let i = 0; i < array.length; i++) {
        if (Array.isArray(arr[i])) {
            depth++;
            arr = arr.flat();
            getArrayDepth(arr);

        }

    }
    return depth + 1;
}
console.log(getArrayDepth(arr));