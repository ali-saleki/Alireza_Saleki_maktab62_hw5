function palindrome(str) {
    const term = str.length;
    const middle = Math.floor(term / 2);
    for (let i = 0, j = term; i <= middle; i++, j--) {
        if (str[i] !== str[j - 1]) {

            return false;
        }

    }
    return true;

}
console.log(palindrome("aammaa"));